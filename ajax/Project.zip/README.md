Florian Rappl demonstrates how to use jQuery's getJSON helper to load JSON-encoded data from a server using a GET HTTP request.

http://www.sitepoint.com/ajaxjquery-getjson-simple/